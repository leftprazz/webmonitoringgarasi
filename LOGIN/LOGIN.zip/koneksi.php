<?php
mysql_connect("localhost","root","") or die ("Gagal Mengkoneksikan Ke Database");
mysql_select_db("login") or die ("Database Tidak Ditemukan");
?>